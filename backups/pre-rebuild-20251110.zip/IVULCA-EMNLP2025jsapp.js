/* app.js - Main application */
document.addEventListener('DOMContentLoaded', function() {
  console.log('✓ Main app loaded');
  console.log('✓ Gallery system ready');
});
