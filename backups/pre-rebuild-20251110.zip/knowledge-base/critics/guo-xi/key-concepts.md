# Guo Xi - Key Concepts

(To be documented)
