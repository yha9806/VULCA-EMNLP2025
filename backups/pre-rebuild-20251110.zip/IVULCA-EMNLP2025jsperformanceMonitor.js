/* performanceMonitor.js - Performance monitoring stub */
window.PerformanceMonitor = window.PerformanceMonitor || {};
