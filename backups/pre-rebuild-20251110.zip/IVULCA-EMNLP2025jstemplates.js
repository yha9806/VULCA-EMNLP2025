/* templates.js - Template utilities stub */
window.Templates = window.Templates || {};
