/**
 * Particles Configuration (stub)
 */
console.log('✓ Particles config loaded');
