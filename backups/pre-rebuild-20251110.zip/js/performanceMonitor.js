/**
 * Performance Monitor (stub)
 */
console.log('✓ Performance monitor loaded');
