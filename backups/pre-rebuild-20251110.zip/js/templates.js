/**
 * Templates (stub)
 */
console.log('✓ Templates loaded');
