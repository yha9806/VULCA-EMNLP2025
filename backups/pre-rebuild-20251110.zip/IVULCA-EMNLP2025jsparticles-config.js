/* particles-config.js - Particle effects configuration */
document.addEventListener('DOMContentLoaded', function() {
  // Sparticles initialization can go here
  console.log('✓ Particles configuration loaded');
});
